// src/App.jsx
import React, { useState, useEffect } from "react";
import MonthSection from "./components/MonthSection/MonthSection";
//import transactionsData from './data/transactions.json';
import NewMonthModal from "./components/NewMonthModal/NewMonthModal";
import {
  getAllMonths,
  createFirstMonth,
  deleteLastMonth,
  createNewMonth,
} from "./services/monthService";
import "./App.css";

function App() {
  //const [months, setMonths] = useState(transactionsData);
  const [months, setMonths] = useState([]);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const storedMonths = await getAllMonths();
      setMonths(storedMonths);
      if (storedMonths.length === 0) {
        setShowModal(true);
      }
    };
    fetchData();
  }, []);

  const refreshMonths = async () => {
    const updatedMonths = await getAllMonths();
    setMonths(updatedMonths);
  };

  const handleAddFirstMonth = (newMonth) => {
    setMonths([...months, newMonth]);
    createFirstMonth(newMonth);
  };
  const handleAddNewMonth = async () => {
    const newMonth = await createNewMonth();
    setMonths([...months, newMonth]);
  };

  const handleDeleteLastMonth = async () => {
    const updatedMonths = await deleteLastMonth();
    setMonths(updatedMonths);
  };

  const calculateMonthData = (initialBalance, debitTransactions) => {
    let balance = initialBalance;
    let totalEntries = 0;
    let totalExits = 0;

    debitTransactions?.forEach((transaction) => {
      if (transaction.type === "entrada") {
        balance += transaction.value;
        totalEntries += transaction.value;
      } else {
        balance -= transaction.value;
        totalExits += transaction.value;
      }
    });

    return {
      finalBalance: balance,
      totalEntries,
      totalExits,
    };
  };

  let initialBalance = 0;

  return (
    <div className="App">
      <header className="app-header">
        <h1>Previsibilidade Financeira</h1>
      </header>

      {months.map((month, index) => {
        const { finalBalance, totalEntries, totalExits } = calculateMonthData(
          initialBalance,
          month.debitTransactions
        );
        const isLastMonth = index === months.length - 1;
        const monthSection = (
          <MonthSection
            key={index}
            month={month}
            monthName={month.name}
            initialBalance={initialBalance}
            debitTransactions={month.debitTransactions}
            creditTransactions={month.creditTransactions}
            finalResult={finalBalance}
            totalEntries={totalEntries}
            totalExits={totalExits}
            isLastMonth={isLastMonth}
            onDeleteLastMonth={handleDeleteLastMonth}
            refreshMonths={refreshMonths}
          />
        );

        initialBalance = finalBalance;
        return monthSection;
      })}

      {!showModal && (
        <div className="fixed-footer">
          <button className="add-month-btn" onClick={handleAddNewMonth}>
            + Criar Novo Mês
          </button>
        </div>
      )}

      {showModal && (
        <NewMonthModal
          onClose={() => setShowModal(false)}
          onCreate={handleAddFirstMonth}
        />
      )}
    </div>
  );
}

export default App;
