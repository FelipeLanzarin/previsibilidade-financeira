// src/components/EditMovementForm/EditMovementForm.jsx
import React, { useState, useEffect, useRef } from "react";
import { formatCurrencyBR, formatDateBR } from "../../utils/formatUtils";
import "./EditMovementForm.css"; // Usamos o mesmo CSS para manter consistência

const EditMovementForm = ({
  movement,
  monthDate,
  onSave,
  onClose,
  handleDelete,
  isDebit,
}) => {
  const [formData, setFormData] = useState({
    date: movement.date,
    description: movement.description,
    value: formatCurrencyBR((movement.value * 100).toString()), // Ajuste aqui
    type: movement.type,
  });
  const [showRecurrenceModal, setShowRecurrenceModal] = useState(false);
  const modalRef = useRef(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let newValue = value;
    if (name === "value") newValue = formatCurrencyBR(value);
    if (name === "date") newValue = formatDateBR(value);
    setFormData((prev) => ({ ...prev, [name]: newValue }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (movement.isRecurring) {
      setShowRecurrenceModal(true);
    } else {
      onSave(
        {
          ...formData,
          value: parseFloat(
            formData.value.replace(/\./g, "").replace(",", ".")
          ),
          day: formData.date.slice(0, 2),
        },
        monthDate,
        movement.id,
        false,
        isDebit
      );
    }
  };

  const handleRecurrenceDecision = (
    editRecurrency,
    monthDate,
    transactionId,
    isDebit
  ) => {
    onSave(
      {
        ...formData,
        value: parseFloat(formData.value.replace(/\./g, "").replace(",", ".")),
        day: formData.date.slice(0, 2),
      },
      monthDate,
      transactionId,
      editRecurrency,
      isDebit
    );
    setShowRecurrenceModal(false);
    onClose();
  };

  const handleClickOutside = (e) => {
    if (modalRef.current && !modalRef.current.contains(e.target)) {
      onClose();
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="modal-overlay">
      <div ref={modalRef} className="modal-content">
        <h3>Editar Movimentação</h3>
        <form onSubmit={handleSubmit}>
          {/* Data */}
          <div className="form-group">
            <label htmlFor="date">Data</label>
            <input
              type="text"
              id="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              placeholder="DD/MM/YYYY"
              required
            />
          </div>

          {/* Descrição */}
          <div className="form-group">
            <label htmlFor="description">Descrição</label>
            <input
              type="text"
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
            />
          </div>

          {/* Valor */}
          <div className="form-group">
            <label htmlFor="value">Valor</label>
            <input
              type="text"
              id="value"
              name="value"
              className="input-right-align"
              value={formData.value}
              onChange={handleChange}
              required
            />
          </div>

          {/* Tipo */}
          <div className="form-group">
            <label htmlFor="type">Tipo</label>
            <select
              id="type"
              name="type"
              value={formData.type}
              onChange={handleChange}
              required
            >
              <option value="saida">Saída</option>
              <option value="entrada">Entrada</option>
            </select>
          </div>

          <button type="submit">Salvar</button>
          <button
            type="button"
            onClick={() => handleDelete(movement)}
            className="btn-delete"
          >
            Deletar
          </button>
          <button type="button" onClick={onClose} className="btn-cancel">
            Cancelar
          </button>
        </form>

        {showRecurrenceModal && (
          <div className="modal-overlay">
            <div className="modal-content">
              <p style={{ textAlign: "center", marginBottom: "20px" }}>
                Deseja editar também a recorrência?
              </p>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  gap: "10px",
                }}
              >
                <button
                  type="button"
                  onClick={() =>
                    handleRecurrenceDecision(
                      true,
                      monthDate,
                      movement.id,
                      isDebit
                    )
                  }
                  style={{
                    backgroundColor: "#4CAF50",
                    color: "white",
                    flex: 1,
                  }}
                >
                  Sim
                </button>
                <button
                  type="button"
                  onClick={() =>
                    handleRecurrenceDecision(
                      false,
                      monthDate,
                      movement.id,
                      isDebit
                    )
                  }
                  style={{
                    backgroundColor: "#f44336",
                    color: "white",
                    flex: 1,
                  }}
                >
                  Não
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EditMovementForm;
