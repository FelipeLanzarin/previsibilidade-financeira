import React, { useState } from "react";
import "./NewMonthModal.css";

const NewMonthModal = ({ onClose, onCreate }) => {
  const [referenceDate, setReferenceDate] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (referenceDate.trim()) {
      const [year, month] = referenceDate.split("-");
      const formattedDate = new Date(year, month - 1);
      const monthName = formattedDate.toLocaleDateString("pt-BR", {
        month: "long",
        year: "numeric",
      });

      onCreate({
        name: monthName.charAt(0).toUpperCase() + monthName.slice(1), // Capitaliza a primeira letra
        date: referenceDate,
        debitTransactions: [],
        creditTransactions: [],
      });

      onClose();
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Criar Mês Inicial</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Data de Referência:
            <input
              type="month"
              value={referenceDate}
              onChange={(e) => setReferenceDate(e.target.value)}
              required
            />
          </label>

          <div className="modal-actions">
            <button type="submit" className="confirm-btn">
              Criar
            </button>
            <button type="button" className="cancel-btn" onClick={onClose}>
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewMonthModal;
