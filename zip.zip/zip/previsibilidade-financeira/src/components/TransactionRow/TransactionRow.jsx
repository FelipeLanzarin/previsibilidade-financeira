// src/components/TransactionRow/TransactionRow.jsx
import React from "react";
import "./TransactionRow.css";
import { formatCurrencyBR } from "../../utils";
import { FaArrowUp, FaArrowDown } from "react-icons/fa";

const TransactionRow = ({
  id,
  date,
  description,
  value,
  type,
  currentBalance,
  openModalEdit,
  isDebit=false,
}) => {
  const isEntry = type === "entrada";

  return (
    <tr
      className={isEntry ? "entry-row" : ""}
      onDoubleClick={() => openModalEdit(id, isDebit)}
    >
      <td>{date}</td>
      <td>{description}</td>
      <td className={isEntry ? "positive" : "negative"}>
        {isEntry ? (
          <FaArrowUp style={{ marginRight: 6 }} />
        ) : (
          <FaArrowDown style={{ marginRight: 6 }} />
        )}
        {formatCurrencyBR(value)}
      </td>
      {currentBalance !== null && (
        <td className={currentBalance >= 0 ? "positive" : "negative"}>
          {formatCurrencyBR(currentBalance)}
        </td>
      )}
    </tr>
  );
};

export default TransactionRow;
