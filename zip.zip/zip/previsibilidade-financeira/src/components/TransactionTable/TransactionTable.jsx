// src/components/TransactionTable/TransactionTable.jsx
import React from "react";
import "./TransactionTable.css";
import TransactionRow from "../TransactionRow/TransactionRow";
import { formatCurrencyBR } from "../../utils";

const TransactionTable = ({
  title,
  transactions,
  initialBalance = 0,
  showSummary = {},
  isDebit = false,
  openModalEdit,
}) => {
  let currentBalance = initialBalance;

  return (
    <div className={`transaction-table ${isDebit ? "debit-table" : ""}`}>
      <h3 className="table-title">{title}</h3>

      {/* RESUMO */}
      {isDebit && showSummary.totalEntries !== undefined && (
        <div className="summary-info">
          Entradas:{" "}
          <span className="positive">
            {formatCurrencyBR(showSummary.totalEntries)}
          </span>{" "}
          | Saídas:{" "}
          <span className="negative">
            {formatCurrencyBR(showSummary.totalExits)}
          </span>
        </div>
      )}
      {!isDebit && showSummary.totalCredit !== undefined && (
        <div className="summary-info">
          Total Gastos:{" "}
          <span className="negative">
            {formatCurrencyBR(showSummary.totalCredit)}
          </span>
        </div>
      )}

      {/* TABELA */}
      <div className="table-scroll-wrapper">
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Descrição</th>
              <th>Valor (R$)</th>
              {isDebit && <th>Saldo Atual</th>}
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => {
              const isEntry = transaction.type === "entrada";
              currentBalance = isEntry
                ? currentBalance + transaction.value
                : currentBalance - transaction.value;

              return (
                <TransactionRow
                  key={index}
                  date={transaction.date}
                  description={transaction.description}
                  value={transaction.value}
                  type={transaction.type}
                  currentBalance={isDebit ? currentBalance : null}
                  openModalEdit={openModalEdit}
                  isDebit
                  id={transaction.id}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TransactionTable;
