import React, { useState } from "react";
import "./MonthSection.css";
import TransactionTable from "../TransactionTable/TransactionTable";
import MovementForm from "../MovementForm/MovementForm";
import EditMovementForm from "../EditMovementForm/EditMovementForm";
import { formatCurrencyBR, calculateFinalResult } from "../../utils";
import {
  addMovementToMonth,
  editMovement,
} from "../../services/movementService";

const MonthSection = ({
  month,
  initialBalance,
  isLastMonth,
  onDeleteLastMonth,
  refreshMonths,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [modalType, setModalType] = useState("debit"); // 'debit' ou 'credit'

  const finalResult = calculateFinalResult(
    initialBalance,
    month.debitTransactions
  );

  const totalEntries = month.debitTransactions
    .filter((t) => t.type === "entrada")
    .reduce((acc, t) => acc + t.value, 0);

  const totalExitsDebit = month.debitTransactions
    .filter((t) => t.type === "saida")
    .reduce((acc, t) => acc + t.value, 0);

  const totalExitsCredit = month.creditTransactions.reduce(
    (acc, t) => acc + t.value,
    0
  );

  const isPositive = finalResult >= 0;

  const openModal = (type) => {
    setModalType(type);
    setModalOpen(true);
  };

  const closeModal = () => setModalOpen(false);
  const closeEditModal = () => setEditModalOpen(false);

  const handleSaveMovement = async (monthDate, movementData, isDebit) => {
    console.log(monthDate);
    await addMovementToMonth(monthDate, movementData, isDebit);
    await refreshMonths();
    closeModal();
  };

  const handleEditMovementSave = async (
    movementData,
    monthDate,
    transactionId,
    editRecurrency,
    isDebit
  ) => {
    await editMovement(
      monthDate,
      transactionId,
      movementData,
      isDebit,
      editRecurrency
    );
    await refreshMonths();
    closeEditModal();
  };

  const [editingMovement, setEditingMovement] = useState(null);

  const openModalEdit = (id, isDebit) => {
    console.log("openModalEdit");
    console.log(id, isDebit);
    const transactions = isDebit
      ? month.debitTransactions
      : month.creditTransactions;
    const movement = transactions.find((m) => m.id === id);
    console.log(movement);
    if (movement) {
      setEditingMovement({ ...movement, isDebit });
      setModalType(isDebit ? "debit" : "credit");
      setEditModalOpen(true);
    }
  };

  return (
    <div className="month-section">
      <h2 className="month-title">{month.name}</h2>
      {isLastMonth && (
        <button className="delete-btn" onClick={onDeleteLastMonth}>
          Deletar Mês
        </button>
      )}

      {/* Tabelas */}
      <div className="tables-container">
        <TransactionTable
          title="Débito"
          transactions={month.debitTransactions}
          initialBalance={initialBalance}
          showSummary={{ totalEntries, totalExits: totalExitsDebit }}
          openModalEdit={openModalEdit}
          isDebit
        />
        <TransactionTable
          title="Crédito"
          transactions={month.creditTransactions}
          showSummary={{ totalCredit: totalExitsCredit }}
          isDebit={false}
        />
      </div>

      {/* Botões */}
      <div className="buttons-container">
        <div className="month-summary">
          <div className="final-result">
            <strong>Saldo:</strong>
            <span className={isPositive ? "positive" : "negative"}>
              {formatCurrencyBR(finalResult)}
            </span>
          </div>
        </div>
        <button
          className="add-btn debit-btn"
          onClick={() => openModal("debit")}
        >
          Adicionar Movimentação
        </button>
        <button
          className="add-btn credit-btn"
          onClick={() => openModal("credit")}
        >
          Adicionar Crédito
        </button>
      </div>

      {/* Resultado final */}

      {/* Modal */}
      {modalOpen && (
        <MovementForm
          closeModal={closeModal}
          monthDate={month.date}
          handleSaveMovement={handleSaveMovement}
          hideTypeField={modalType === "credit"}
          isDebit={modalType !== "credit"}
        />
      )}
      {/* Modal */}
      {editModalOpen && (
        <EditMovementForm
          movement={editingMovement}
          monthDate={month.date}
          onSave={handleEditMovementSave}
          onClose={() => setEditModalOpen(false)}
          isDebit
        />
      )}
    </div>
  );
};

export default MonthSection;
