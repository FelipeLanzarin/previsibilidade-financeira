import React, { useState, useRef, useEffect } from "react";
import { formatCurrencyBR, formatDateBR } from "../../utils/formatUtils";
import "./MovementForm.css";

const MovementForm = ({
  closeModal,
  monthDate,
  handleSaveMovement, // função chamada com o objeto { date, description, value, type, day, isRecurring }
  hideTypeField, // boolean — quando true, não exibe o select de tipo
  isDebit,
}) => {
  // inicializa data atual
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, "0");
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const yyyy = today.getFullYear();
  const [date, setDate] = useState(`${dd}/${mm}/${yyyy}`);
  const [description, setDescription] = useState("");
  const [value, setValue] = useState("");
  const [type, setType] = useState("saida");
  const [isRecurring, setIsRecurring] = useState(false);
  const modalRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    handleSaveMovement(
      monthDate,
      {
        date,
        description,
        value: parseFloat(value.replace(/\./g, "").replace(",", ".")),
        type,
        day: date.slice(0, 2),
        isRecurring,
      },
      isDebit
    );
  };

  const handleClickOutside = (e) => {
    if (modalRef.current && !modalRef.current.contains(e.target)) {
      closeModal();
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="modal-overlay">
      <div ref={modalRef} className="modal-content">
        <h3>Adicionar Movimentação</h3>
        <form onSubmit={handleSubmit}>
          {/* Data */}
          <div className="form-group">
            <label htmlFor="date">Data</label>
            <input
              type="text"
              id="date"
              value={date}
              onChange={(e) => setDate(formatDateBR(e.target.value))}
              placeholder="DD/MM/YYYY"
              required
            />
          </div>

          {/* Descrição */}
          <div className="form-group">
            <label htmlFor="description">Descrição</label>
            <input
              type="text"
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          {/* Valor */}
          <div className="form-group">
            <label htmlFor="value">Valor</label>
            <input
              type="text"
              id="value"
              className="input-right-align"
              value={value}
              onChange={(e) => setValue(formatCurrencyBR(e.target.value))}
              required
            />
          </div>

          {/* Tipo (só se hideTypeField === false) */}
          {!hideTypeField && (
            <div className="form-group">
              <label htmlFor="type">Tipo</label>
              <select
                id="type"
                value={type}
                onChange={(e) => setType(e.target.value)}
                required
              >
                <option value="saida">Saída</option>
                <option value="entrada">Entrada</option>
              </select>
            </div>
          )}

          {/* Recorrente */}
          <div className="form-group form-group-recurring">
            <label htmlFor="recurring">Recorrente</label>
            <input
              type="checkbox"
              id="recurring"
              checked={isRecurring}
              onChange={() => setIsRecurring(!isRecurring)}
            />
          </div>

          <button type="submit">Salvar</button>
          <button type="button" onClick={closeModal}>
            Cancelar
          </button>
        </form>
      </div>
    </div>
  );
};

export default MovementForm;
