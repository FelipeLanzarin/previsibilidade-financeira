
import { loadRecurrences, saveRecurrences } from './storageService';
import { generateId } from '../utils/idUtils';
import { getPreviousMonth } from '../utils/dateUtils';

/**
 * Retorna todas as recorrências salvas
 */
export async function getAllRecurrences(method) {
  return await loadRecurrences(method);
}

/**
 * Cadastra uma nova movimentação recorrente
 * precisa ajustar para cadastrar em todos os meses ativos após o monthStart
 */
export async function createRecurrence({ description, value, type, day, monthStart, method }) {
  const recurrences = await loadRecurrences(method);

  const newRecurrence = {
    id: generateId(),
    description,
    value,
    type,
    day,
    monthStart, // Ex: "2025-05"
    monthEnd: null, // Ativo até alterar/excluir
  };

  recurrences.push(newRecurrence);
  await saveRecurrences(recurrences, method);

  return newRecurrence;
}

/**
 * Edita uma recorrência a partir de um certo mês
 */
export async function editRecurrence(recurrenceId, updatedData, effectiveMonth, method) {
  const recurrences = await loadRecurrences(method);
  const recurrence = recurrences.find(r => r.id === recurrenceId);

  if (!recurrence) {
    throw new Error('Recorrência não encontrada.');
  }

  const previousMonth = getPreviousMonth(effectiveMonth);

  // Finaliza a recorrência antiga
  recurrence.monthEnd = previousMonth;

  // Cria uma nova recorrência com os novos dados

  // talvez usar o metodo de criar, que ja vai criar em todos os meses.
  const newRecurrence = {
    id: generateId(),
    description: updatedData.description,
    value: updatedData.value,
    type: updatedData.type,
    day: updatedData.day,
    monthStart: effectiveMonth,
    monthEnd: null,
  };

  recurrences.push(newRecurrence);

  await saveRecurrences(recurrences, method);

  return newRecurrence;
}

/**
 * Exclui uma recorrência a partir de um certo mês
 * deletar essa recorrencia nos outros meses
 */
export async function deleteRecurrence(recurrenceId, effectiveMonth, method) {
  const recurrences = await loadRecurrences(method);
  const recurrence = recurrences.find(r => r.id === recurrenceId);

  if (!recurrence) {
    throw new Error('Recorrência não encontrada.');
  }

  const previousMonth = getPreviousMonth(effectiveMonth, method);

  // Finaliza a recorrência para não aparecer mais nos meses seguintes
  recurrence.monthEnd = previousMonth;

  await saveRecurrences(recurrences, method);
}
