const MONTHS_KEY = 'months-data';
const RECURRENCES_KEY = 'recurrences-data-';

export async function loadMonths() {
  const data = localStorage.getItem(MONTHS_KEY);
  console.log(data);
  return data ? JSON.parse(data) : [];
}

export async function saveMonths(months) {
  localStorage.setItem(MONTHS_KEY, JSON.stringify(months));
}

export async function loadRecurrences(method) {
  const data = localStorage.getItem(RECURRENCES_KEY+method);
  return data ? JSON.parse(data) : [];
}

export async function saveRecurrences(recurrences, method) {
  localStorage.setItem(RECURRENCES_KEY + method, JSON.stringify(recurrences));
}
