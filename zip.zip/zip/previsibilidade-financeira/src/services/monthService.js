import { loadMonths, saveMonths } from './storageService';
import { getAllRecurrences } from './recurrenceService';
import { createMonthFromTemplate, formatMonthName } from '../utils/monthUtils';
import { getNextMonth } from '../utils/dateUtils';

const DEBIT_RECURRENCY = 'debit';
const CREDIT_RECURRENCY = 'credit';



export async function createFirstMonth(referenceDate) {
  const debitRecurrences = await getAllRecurrences(DEBIT_RECURRENCY);
  const creditRecurrences = await getAllRecurrences(CREDIT_RECURRENCY);

  const newMonth = createMonthFromTemplate(referenceDate, debitRecurrences, creditRecurrences);
  const months = [newMonth];

  await saveMonths(months);

  return newMonth;
}

export async function createNewMonth() {
  const months = await loadMonths();
  const debitRecurrences = await getAllRecurrences(DEBIT_RECURRENCY);
  const creditRecurrences = await getAllRecurrences(CREDIT_RECURRENCY);
  
  console.log(debitRecurrences);
  console.log(creditRecurrences);

  const lastMonth = months[months.length - 1];
  const nextDate = getNextMonth(lastMonth.date); // Retorna uma string 'yyyy-mm'
  const name = formatMonthName(nextDate)
  const newMonth = createMonthFromTemplate(
    {
      name: name.charAt(0).toUpperCase() + name.slice(1),
      date: nextDate
    },
    debitRecurrences,
    creditRecurrences
  );

  months.push(newMonth);
  await saveMonths(months);

  return newMonth;
}


export async function getAllMonths() {
  return await loadMonths();
}

export async function deleteLastMonth() {
  const months = await loadMonths();
  if (months.length > 0) {
    months.pop(); // Remove o último mês
    await saveMonths(months);
  }
  return months;
}
