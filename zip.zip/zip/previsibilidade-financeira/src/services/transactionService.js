import { loadMonths, saveMonths } from './storageService';

export async function addTransaction(monthId, transaction, isDebit = true) {
  const months = await loadMonths();
  const month = months.find(m => m.month === monthId);

  if (!month) throw new Error('Mês não encontrado');

  if (isDebit) {
    month.debitTransactions.push(transaction);
  } else {
    month.creditTransactions.push(transaction);
  }

  await saveMonths(months);
}
