// src/services/movementService.js
import { loadMonths, saveMonths } from './storageService';
import { generateId } from '../utils/idUtils';
import { createRecurrence } from './recurrenceService'; // Supondo que esse seja o local

/**
 * Adiciona uma movimentação (recorrente ou não) ao mês correspondente.
 * 
 * @param {string} monthDate - Data do mês (formato YYYY-MM)
 * @param {object} movementData - Dados da movimentação
 * @param {string} transactionType - 'credito' ou 'debito'
 */
export async function addMovementToMonth(monthDate, movementData, isDebit) {
  const months = await loadMonths();
  const month = months.find(m => m.date === monthDate);

  if (!month) {
    throw new Error('Mês não encontrado.');
  }

  const newMovement = {
    id: generateId(),
    date: movementData.date,
    description: movementData.description,
    value: movementData.value,
    type: movementData.type,
    isRecurring: movementData.isRecurring,
    day: movementData.day,
  };

  const transactionKey = isDebit 
    ? 'debitTransactions'
    : 'creditTransactions';

  const method = isDebit 
    ? 'debit'
    : 'credit';
  
  month[transactionKey].push(newMovement);
  month[transactionKey] = sortTransactionsByDate(month[transactionKey]);

  // Se for recorrente, salvar também no sistema de recorrência
  if (newMovement.isRecurring) {
    await createRecurrence({
      description: newMovement.description,
      value: newMovement.value,
      type: newMovement.type,         // 'entrada' ou 'saida'
      day: newMovement.day,
      monthStart: month.date,         // Mês em que começa
      method: method         // 'credito' ou 'debito'
    });
  }

  await saveMonths(months);
  return newMovement;
}

export async function editMovement(monthDate, transactionId, updatedData, isDebit, editRecurrency) {
  const months = await loadMonths();
  const month = months.find(m => m.date === monthDate);
  
  if (!month) {
    throw new Error('Mês não encontrado.');
  }
  const transactionKey = isDebit ? 'debitTransactions' : 'creditTransactions';
  const transactions = month[transactionKey];

  const index = transactions.findIndex(t => t.id === transactionId);
  if (index === -1) {
    throw new Error('Transação não encontrada.');
  }

  transactions[index] = { ...transactions[index], ...updatedData };
  month[transactionKey] = sortTransactionsByDate(transactions);

  await saveMonths(months);
  console.log(editRecurrency)
  return transactions[index];
}

export async function deleteMovement(monthDate, transactionId, isDebit) {
  const months = await loadMonths();
  const month = months.find(m => m.date === monthDate);

  if (!month) {
    throw new Error('Mês não encontrado.');
  }

  const transactionKey = isDebit ? 'debitTransactions' : 'creditTransactions';
  const transactions = month[transactionKey];

  const index = transactions.findIndex(t => t.id === transactionId);
  if (index === -1) {
    throw new Error('Transação não encontrada.');
  }

  // Remove a transação pelo índice
  const [deletedTransaction] = transactions.splice(index, 1);

  // Atualiza o mês com as transações restantes
  month[transactionKey] = sortTransactionsByDate(transactions);

  await saveMonths(months);

  return deletedTransaction; // Retorna a transação deletada para referência
}

function sortTransactionsByDate(transactions) {
  return transactions.sort((a, b) => {
    const [dayA, monthA, yearA] = a.date.split("/").map(Number);
    const [dayB, monthB, yearB] = b.date.split("/").map(Number);

    const dateA = new Date(yearA, monthA - 1, dayA);
    const dateB = new Date(yearB, monthB - 1, dayB);

    return dateA - dateB;
  });
}