// Pega o mês anterior de uma string yyyy-mm
export function getPreviousMonth(currentMonth) {
    const [year, month] = currentMonth.split('-').map(Number);
    const prevDate = new Date(year, month - 2); // mês começa do zero em JS
    const prevYear = prevDate.getFullYear();
    const prevMonth = String(prevDate.getMonth() + 1).padStart(2, '0');
  
    return `${prevYear}-${prevMonth}`;
  }
  
/**
 * Recebe um mês no formato 'yyyy-mm' e retorna o próximo mês no mesmo formato
 * @param {string} currentMonth
 * @returns {string}
 */
export function getNextMonth(currentMonth) {
    const [year, month] = currentMonth.split('-').map(Number);
  
    const nextMonth = month === 12 ? 1 : month + 1;
    const nextYear = month === 12 ? year + 1 : year;
  
    // Formata para 'yyyy-mm' garantindo dois dígitos no mês
    const nextMonthFormatted = String(nextMonth).padStart(2, '0');
  
    return `${nextYear}-${nextMonthFormatted}`;
  }