// src/utils/formatUtils.js

/**
 * Formata um valor numérico (string) no padrão de moeda brasileira.
 * Ex: "1000000" → "1.000.000,00"
 */
export const formatCurrencyBR = (value) => {
  if (!value) return "0,00";

  // Remove caracteres não numéricos
  const numericValue = parseFloat(value.replace(/[^\d]/g, ""));

  // Divide por 100 para ajustar casas decimais e formata no padrão brasileiro
  return (numericValue / 100).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).replace("R$", "").trim();
};
  
  /**
   * Formata uma string numérica no padrão de data DD/MM/YYYY.
   * Ex: "01042025" → "01/04/2025"
   */
  export function formatDateBR(value) {
    const digits = value.replace(/\D/g, '').slice(0, 8);
    const parts = [];
    if (digits.length > 0) parts.push(digits.slice(0, 2));
    if (digits.length > 2) parts.push(digits.slice(2, 4));
    if (digits.length > 4) parts.push(digits.slice(4, 8));
    return parts.join('/');
  }
  

  export function formatDateBR2(dateStr) {
    const [year, month, day] = dateStr.split("-");
    return `${day}/${month}/${year}`;
  }