/**
 * Gera um ID único baseado em data/hora e um random
 * @returns {string}
 */
export function generateId() {
    return `${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  }