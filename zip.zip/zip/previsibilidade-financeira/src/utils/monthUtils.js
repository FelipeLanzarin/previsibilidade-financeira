import { generateId } from './idUtils'; 
import {formatDateBR2} from './formatUtils'// também deve existir

export function createMonthFromTemplate(newMonth, debitRecurrences, creditRecurrences) {
  return {
    name: newMonth.name,
    date: newMonth.date,
    debitTransactions: createTransactions(newMonth, debitRecurrences),
    creditTransactions:createTransactions(newMonth, creditRecurrences),
  };
}

function createTransactions(newMonth, recurrences){
  var transactions = [];
  recurrences.forEach(recurrence => {
    const isActive = 
      (!recurrence.monthStart || recurrence.monthStart <= newMonth) &&
      (!recurrence.monthEnd || recurrence.monthEnd >= newMonth);

    if (isActive) {
      var date = formatDateBR2(`${newMonth.date}-${recurrence.day}`);
      transactions.push({
        id: generateId(),
        date: date,
        description: recurrence.description,
        value: recurrence.value,
        type: recurrence.type,
        isRecurring: true,
        recurrenceId: recurrence.id,
      });
    }
  });
  return transactions;
}

export function  formatMonthName(month) {
  const [year, monthNum] = month.split('-').map(Number);
  const date = new Date(year, monthNum - 1);
  return date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
}
