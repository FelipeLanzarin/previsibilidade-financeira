
export function formatCurrencyBR(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
  

export const calculateFinalResult = (initialBalance, debitTransactions) => {
  return debitTransactions?.reduce((balance, transaction) => {
    return transaction.type === 'entrada'
      ? balance + transaction.value
      : balance - transaction.value;
  }, initialBalance);
}